const form = document.querySelector(".js-form"),
  input = form.querySelector("input"),
  greeting = document.querySelector(".js-greetings");
const USER_LS = "currentUser",
  SHOWING_CN = "showing";

///////////////////////////todo
const toDoForm = document.querySelector(".js-toDoForm"),
  toDoInput = toDoForm.querySelector("input"),
  toDoList = document.querySelector(".js-toDoList");

const TODOS_LS = "toDos";

let toDos = []; //할일 목록을 저장할 비어있는 배열 생성
//해야할일 생성 시, 이 배열에 추가되도록 할것임.
function deleteToDo(event){
    const btn=event.target;
    const li=btn.parentNode;
    toDoList.removeChild(li);
  const cleanToDos = toDos.filter(function(toDo) {
    return toDo.id !== parseInt(li.id);
  });
  toDos = cleanToDos;
  saveToDos();
}

function saveToDos() {
  localStorage.setItem(TODOS_LS, JSON.stringify(toDos));
}

function paintToDo(text)  {
    const li = document.createElement("li");
    const delBtn = document.createElement("button");
    const span = document.createElement("span");
    const newId = toDos.length + 1;
    delBtn.innerText = "❌";
    delBtn.addEventListener("click", deleteToDo); //버튼에 이벤트 추가
    span.innerText = text;
    li.appendChild(delBtn);
    li.appendChild(span);
    li.id = newId;
    toDoList.appendChild(li);
    const toDoObj = {
      text: text,
      id: newId
    };
    toDos.push(toDoObj);
    saveToDos();
  }

  
function handleSubmit(event) {
    event.preventDefault();
    const currentValue = toDoInput.value;
    paintToDo(currentValue);
    toDoInput.value = "";
  }

function loadToDos() {
    const loadedToDos = localStorage.getItem(TODOS_LS);
    if (loadedToDos !== null) {
      const parsedToDos = JSON.parse(loadedToDos);
      parsedToDos.forEach(function(toDo) {
        paintToDo(toDo.text);
      });
    }
  }

  function printWhattodo(){
    //var newForm = document.createElement('form');
 var a;
 window.addEventListener("load",function(){
   a=document.getElementById("a");
 });

 const input = document.createElement("input");
 input.name="todotext";
 a.appendChild(input);
 input.textContent("Write ");
}

///////////////////////////여기까지

function addJavascript(jsname) {

    var th = document.getElementsByTagName('head')[0];
  
    var s = document.createElement('script');
  
    s.setAttribute('type','text/javascript');
  
    s.setAttribute('src',jsname);
  
    th.appendChild(s);
  
}

function saveName(text) {
  localStorage.setItem(USER_LS, text);
}

function handleSubmit(event) {
  event.preventDefault();
  const currentValue = input.value;
  paintGreeting(currentValue);
  saveName(currentValue);
}

function askForName() {
  form.classList.add(SHOWING_CN);
  form.addEventListener("submit", handleSubmit);
}



function paintGreeting(text) {
  const date=new Date();
  const hours = date.getHours();
  form.classList.remove(SHOWING_CN);
  greeting.classList.add(SHOWING_CN);
  if(hours>=6 && hours <=11)
  {greeting.innerText = `${text}, Good morning`;}
  else if(hours>=12 && hours <=15)
  {greeting.innerText = `Good afternoon ${text} !`;}
  else if(hours>=17 && hours <=20)
  {greeting.innerText = `Good evening ${text}`;}
  else if(hours>=21 && hours <=24)
  {greeting.innerText = `Good night ${text}`;}
  else 
  {
    greeting.innerText = `What's going on ${text} ?`;
  }
}

function loadName() {
  const currentUser = localStorage.getItem(USER_LS);
  if (currentUser === null) {
    // she is not
    askForName();


  } else {
    paintGreeting(currentUser);
    
    loadToDos();
    toDoForm.addEventListener("submit", handleSubmit);
    
  }
}




function init() {
  loadName();
}
init();
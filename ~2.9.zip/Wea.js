const API_KEY = "93c324a7c3d4608b0561fab7fca1cb40";


_getWeather = (lat, lng) => {
    fetch(`http://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lng}&APPID=${API_KEY}`)
    .then(response => response.json())
    .then(json => {
      this.setState({
        temperature: json.main.temp,
        name: json.weather[0].main,
        isLoaded: true
      })
    })
  }





state = {
    isLoaded: false,
    error: null,
    temperature: null,
    name: null
  };


function Weather({ temp }){
    return(
        <LinearGradient
            colors={["#00C6FB", "#005BEA"]} //from-to 색상 지정
            style={styles.container} //스타일
        >
            <View style={styles.upper}>
                <Ionicons color="white" size={144} name="ios-rainy" />
                <Text style={styles.temp}>{temp}˚</Text>
            </View>
            <View style={styles.lower}>
                <Text style={styles.title}>Rainning</Text>
                <Text style={styles.subtitle}>For more info look outside</Text>
            </View>
        </LinearGradient>
    );
}

Weather.propTypes = {
    temp: PropTypes.number.isRequired
}
